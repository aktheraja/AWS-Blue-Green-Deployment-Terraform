import boto3
import sys
from datetime import datetime
import time
import os

def lambda_handler(event, context):
    global inactiveAutoscalinggroups
    inactiveAutoscalinggroups = False

    # Retrieve autoscaling group names
    agBlue = os.environ['asg_blue']
    agGreen = os.environ['asg_green']
    ami = os.environ['ami']
   # ami="ami-07669fc90e6e6cc47"
    inactiveDesired = 1
   # agBlue =  'asg_blue'
   # agGreen = 'asg_green'
    maxTimeout = 200
    # Retrieve autoscaling groups information
    info = getAutoscalingInfo(agBlue, agGreen)
    # Determine the active autoscaling group
    active = getActive(info)
    # Bring up the not active autoscaling group with the new AMI
    desiredInstanceCount = newAutoscaling(info, active, ami, inactiveDesired, agBlue, agGreen)
    # Retieve all ELBs and ALBs
    elbs = getLoadbalancers(info, 'elb')
    albs = getLoadbalancers(info, 'alb')
    # Retrieve autoscaling groups information again
    info = getAutoscalingInfo(agBlue, agGreen)
    #desiredInstanceCount=3
    time.sleep(50)
    print("am here 199")
    timeout = 30
    while checkScalingStatus(info, elbs, albs, desiredInstanceCount) is not True:
        print("am here 202")
        if timeout > maxTimeout:
            print ('Roling back')
            rollbackAutoscaling(info, active, ami, agBlue, agGreen)
            sys.exit(1)
        
        print ('Waiting for 10 seconds to get autoscaling status')
        time.sleep(10)
        timeout += 10
    print ('We can stop the old autoscaling now')
    oldAutoscaling(info, active, ami, agBlue, agGreen)
    if inactiveAutoscalinggroups:
        print ('Deactivating the autoscaling')
        stopAutoscaling(info, active, ami,agBlue, agGreen)

def stopAutoscaling(info, active, ami,agBlue, agGreen):
    blueMin = info['AutoScalingGroups'][active]['MinSize']
    blueMax = info['AutoScalingGroups'][active]['MaxSize']
    blueDesired = 0

    greenMin = info['AutoScalingGroups'][active]['MinSize']
    greenMax = info['AutoScalingGroups'][active]['MaxSize']
    greenDesired = 0

    if active == 0:
        blueAMI = getAmi(info['AutoScalingGroups'][active]['LaunchConfigurationName'])
        greenAMI = ami
    elif active == 1:
        blueAMI = ami
        greenAMI = getAmi(info['AutoScalingGroups'][active]['LaunchConfigurationName'])
    else:
        print ('No acive AMI')
        sys.exit(1)
    updateAutoscaling(blueMax, blueMin, blueDesired, blueAMI, greenMax, greenMin, greenDesired, greenAMI,  agBlue, agGreen)


def oldAutoscaling(info, active, ami,agBlue, agGreen):
    blueAMI = getAmi(info['AutoScalingGroups'][0]['LaunchConfigurationName'])
    greenAMI = getAmi(info['AutoScalingGroups'][1]['LaunchConfigurationName'])
    if active == 0:
        blueMin = 0
        blueMax = 0
        blueDesired = 0

        greenMin = info['AutoScalingGroups'][active]['MinSize']
        greenMax = info['AutoScalingGroups'][active]['MaxSize']
        if inactiveAutoscalinggroups:
            greenDesired = 0
        else:
            greenDesired = info['AutoScalingGroups'][active]['DesiredCapacity']
    elif active == 1:
        blueMin = info['AutoScalingGroups'][active]['MinSize']
        blueMax = info['AutoScalingGroups'][active]['MaxSize']
        if inactiveAutoscalinggroups:
            blueDesired = 0
        else:
            blueDesired = info['AutoScalingGroups'][active]['DesiredCapacity']

        greenMin = 0
        greenMax = 0
        greenDesired = 0
    else:
        print ('No acive AMI')
        sys.exit(1)
        
    updateAutoscaling(blueMax, blueMin, blueDesired, blueAMI, greenMax, greenMin, greenDesired, greenAMI,  agBlue, agGreen)


def rollbackAutoscaling(info, active, ami, agBlue, agGreen):
    blueAMI = getAmi(info['AutoScalingGroups'][0]['LaunchConfigurationName'])
    greenAMI = getAmi(info['AutoScalingGroups'][1]['LaunchConfigurationName'])

    if active == 0:
        blueMin = info['AutoScalingGroups'][0]['MinSize']
        blueMax = info['AutoScalingGroups'][0]['MaxSize']
        if inactiveAutoscalinggroups:
            blueDesired = 0
        else:
            blueDesired = info['AutoScalingGroups'][0]['DesiredCapacity']

        greenMin = 0
        greenMax = 0
        greenDesired = 0
    elif active == 1:
        greenMin = info['AutoScalingGroups'][1]['MinSize']
        greenMax = info['AutoScalingGroups'][1]['MaxSize']
        if inactiveAutoscalinggroups:
            greenDesired = 0
        else:
            greenDesired = info['AutoScalingGroups'][1]['DesiredCapacity']

        blueMin = 0
        blueMax = 0
        blueDesired = 0
    else:
        print ('No acive AMI')
        sys.exit(1)

    updateAutoscaling(blueMax, blueMin, blueDesired, blueAMI, greenMax, greenMin, greenDesired, greenAMI,  agBlue, agGreen)
def getLaunchconfigDate(launchconfig):
    client = boto3.client('autoscaling')
    response = client.describe_launch_configurations(
        LaunchConfigurationNames=[
            launchconfig,
        ],
        MaxRecords=1
    )
    return datetime.strptime(response['LaunchConfigurations'][0]['CreatedTime'], '%Y-%m-%dT%H:%M:%S.%fZ')
def getActive(info):
    if info['AutoScalingGroups'][0]['DesiredCapacity'] > 0 and info['AutoScalingGroups'][1]['DesiredCapacity'] == 0:
        print ('Blue is active')
        return 0
    elif info['AutoScalingGroups'][0]['DesiredCapacity'] == 0 and info['AutoScalingGroups'][1]['DesiredCapacity'] > 0:
        print ('Green is active')
        return 1
    elif info['AutoScalingGroups'][0]['DesiredCapacity'] == 0 and info['AutoScalingGroups'][1]['DesiredCapacity'] == 0:
        print ('Both are inactive')
        global inactiveAutoscalinggroups
        inactiveAutoscalinggroups = True

        blueDate = getLaunchconfigDate(info['AutoScalingGroups'][0]['LaunchConfigurationName'])
        greenDate = getLaunchconfigDate(info['AutoScalingGroups'][1]['LaunchConfigurationName'])
        # use the ASG with the oldest launch config
        if blueDate < greenDate:
            print ('Blue has oldest launchconfig')
            return 1
        else:
            print ('Green has oldest launchconfig')
            return 0
    else:
        print ('Both are active')
        sys.exit(1)
def getAutoscalingInfo(blue, green):
    client = boto3.client('autoscaling')
    response = client.describe_auto_scaling_groups(
        AutoScalingGroupNames=[
            blue,
            green,
        ],
        MaxRecords=2
    )
    
    return response

def checkScalingStatus(info, elbs, albs, desiredInstanceCount):
    client_ec2 = boto3.client('ec2')
    client = boto3.client('elb')
    for elb in elbs:
        print(elb)
        response = client.describe_instance_health(
            LoadBalancerName=elb
        )
        if desiredInstanceCount > len(response['InstanceStates']):
            print ('Not enough instances inside ELB, we expect ' + str(desiredInstanceCount) + ' and got ' + str(len(response['InstanceStates'])))
            return False
        for state in response['InstanceStates']:
            print ('ELB: ' + state['State'])
            if state['State'] != 'InService':
                return False
    client = boto3.client('elbv2')
    for alb in albs:
        response = client.describe_target_health(
            TargetGroupArn=alb,
        )
        if desiredInstanceCount > len(response['TargetHealthDescriptions']):
            print ('Not enough instances inside ALB, we expect ' + str(desiredInstanceCount) + ' and got ' + str(len(response['TargetHealthDescriptions'])))
            return False
        for state in response['TargetHealthDescriptions']:
            print ('ALB: ' + state['TargetHealth']['State'])
            print ('instance: ' + state ['Target']['Id'])
            instanceId=state ['Target']['Id']
            response = client_ec2.describe_instance_status(InstanceIds=[instanceId])
            
            instance_status=response['InstanceStatuses'][0]['InstanceStatus']['Details'][0]['Status']
            instance_Name=response['InstanceStatuses'][0]['SystemStatus']['Details'][0]['Status']
            instance_status_2=response['InstanceStatuses'][0]['InstanceStatus']['Status']
            instance_Name_2=response['InstanceStatuses'][0]['SystemStatus']['Status']
            
                      
            if instance_status =='initializing' or instance_status_2 =='initializing' or \
            instance_Name == 'initializing' or instance_Name_2 == 'initializing':
                print(instance_Name_2)
                return False
    return True
    
    

def getLoadbalancers(info, type):
    if type == 'alb':
        return info['AutoScalingGroups'][0]['TargetGroupARNs']
    else:
        return info['AutoScalingGroups'][0]['LoadBalancerNames']

def updateAutoscaling(blueMax, blueMin, blueDesired, blueAMI, greenMax, greenMin, greenDesired, greenAMI,  agBlue, agGreen):
    print(greenMax)
    #bring up the instance
    client = boto3.client('autoscaling')
    response = client.update_auto_scaling_group(
    AutoScalingGroupName=agGreen,
    MinSize=greenMin,
    MaxSize=greenMax,
    DesiredCapacity=greenDesired,
    DefaultCooldown=123)
    
    response2 = client.update_auto_scaling_group(
    AutoScalingGroupName=agBlue,
    MinSize=blueMin,
    MaxSize=blueMax,
    DesiredCapacity=blueDesired,
    DefaultCooldown=123)


def getAmi(launchconfig):
    client = boto3.client('autoscaling')
    response = client.describe_launch_configurations(
        LaunchConfigurationNames=[
            launchconfig,
        ],
        MaxRecords=1
    )
    return response['LaunchConfigurations'][0]['ImageId']
    
def newAutoscaling(info, active, ami, inactiveDesired, agBlue, agGreen):
    blueMin = info['AutoScalingGroups'][active]['MinSize']
    blueMax = info['AutoScalingGroups'][active]['MaxSize']
    blueDesired = info['AutoScalingGroups'][active]['DesiredCapacity']

    greenMin = info['AutoScalingGroups'][active]['MinSize']
    greenMax = info['AutoScalingGroups'][active]['MaxSize']
    greenDesired = info['AutoScalingGroups'][active]['DesiredCapacity']

    if active == 0:
        blueAMI = getAmi(info['AutoScalingGroups'][active]['LaunchConfigurationName'])
        greenAMI = ami
        if inactiveAutoscalinggroups:  # if we are dealing with empty asgs we override the desired capacity
            greenDesired = inactiveDesired
    elif active == 1:
        blueAMI = ami
        greenAMI = getAmi(info['AutoScalingGroups'][active]['LaunchConfigurationName'])
        if inactiveAutoscalinggroups:  # if we are dealing with empty asgs we override the desired capacity
            blueDesired = inactiveDesired
    else:
        print ('No acive AMI')
        sys.exit(1)

    updateAutoscaling(blueMax, blueMin, blueDesired, blueAMI, greenMax, greenMin, greenDesired, greenAMI,  agBlue, agGreen)
        # Return the amount of instances we should see in ELBs and ALBs. This is * 2 because we need to think about both autoscaling groups.
    # unless we are working with empty asgs
    if inactiveAutoscalinggroups:
        return inactiveDesired
    else:
        return info['AutoScalingGroups'][active]['DesiredCapacity']




